open Model
open ANSITerminal

let print_exit () : unit =
  print_string [red;Bold] "EXITING GAME (come back!)\n"

let print_play_help () : unit =
  print_string [red;Bold] "VALID COMMANDS ARE:\n";
  print_string [default] "'raise i' where 'i' is a non-negative integer\n";
  print_string [default] "'bet i' where 'i' is a non-negative integer\n";
  print_string [default] "'match'\n";
  print_string [default] "'check'\n";
  print_string [default] "'fold'\n";
  print_string [default] "'exit' exits the game\n";
  print_string [default;Bold] "(press any key to continue)"

let print_help () : unit =
  print_string [red;Bold] "HELP TO PLAY POKER:\n";
  print_string [default]
  "  https://www.partypoker.com/en/how-to-play/texas-holdem gives a good overview of the rules of the poker we implemented.
  https://www.partypoker.com/en/how-to-play/hand-rankings gives a good overview of the card rankings we use.
  Note that we don't fully implement these rules or card rankings--yet.\n\n";
  print_play_help ()

(**[card_num_to_string i] is the card representation of [i]
Raises: fails if 14 < [i] < 2
Example: [card_num_to_string 14] is ["Ace"]
         [card_num_to_string 2] is ["Two"]**)
let card_num_to_string (i:int) : string =
  match i with
  | 14 -> "Ace"
  | 13 -> "King"
  | 12 -> "Queen"
  | 11 -> "Jack"
  | 10 -> "Ten"
  | 9 -> "Nine"
  | 8 -> "Eight"
  | 7 -> "Seven"
  | 6 -> "Six"
  | 5 -> "Five"
  | 4 -> "Four"
  | 3 -> "Three"
  | 2 -> "Two"
  | _ -> failwith "invalid card"

(**[card_to_string c] is a [string] representation of card [c]**)
let card_to_string (c:Model.card) : string * style =
  match c.s,c.v with
  | Hearts,i -> (card_num_to_string i) ^ " of Hearts", red
  | Clubs,i -> (card_num_to_string i) ^ " of Clubs", default
  | Diamonds,i -> (card_num_to_string i) ^ " of Diamonds", red
  | Spades,i -> (card_num_to_string i) ^ " of Spades", default

(**[print_cards c] prints [string] representations of the cards in [c]**)
let rec print_cards (cards:Model.card list) : unit =
  match cards with
  | [] -> ()
  | h::t -> print_string [(snd (card_to_string h))] ( (fst (card_to_string h)) ^ "\n"); print_cards t

let print_winner (p:Model.player) (g:Model.game) : unit =
  print_string [cyan] ("\n\n\n" ^ (Model.get_name p) ^ " won with private cards\n");
  print_cards (Model.get_player_cards p)

let default_color = green

(**[player_to_string p] is the [string] representations player [p]**)
let player_to_string (p:Model.player) : string =
  (Model.get_name p) ^
  "  -  Chips: " ^ (string_of_int (Model.get_chips p)) ^
  "  -  Has folded: " ^ (string_of_bool (Model.has_folded p) ^
  "  -  Amount bet: " ^ (string_of_int (Model.get_player_bet p)))

(**[print_players p] prints [string] representations of the players in [c]**)
let rec print_players (cp: Model.player) (players:Model.player list) : unit =
  match players with
  | [] -> ()
  | h::t -> if h = cp then
    let _ = print_string [cyan;Bold] ("-> " ^ (player_to_string h) ^ "\n") in
    print_players cp t
    else let _ = print_string [cyan] ((player_to_string h) ^ "\n") in
    print_players cp t

let print_game (g:Model.game) : unit =
  try let p = Model.get_current_player g in
  let p_cards = Model.get_player_cards p in
    let p_name = Model.get_name p in
    let t_cards = Model.get_table g in
    let players = Model.get_players g in
      print_string [] "\n\n";
      print_string [default_color; Bold] (p_name ^ "'s Turn \n");
      print_string [blue] ("----------------------------------------------------\n");
      print_string [default_color; Bold] (p_name ^ "'s cards: \n");
      print_cards p_cards;
      print_string [default_color; Bold] ("----------------------------------------------------\n");
      print_string [default_color; Bold] "\nTable cards: \n";
      print_cards t_cards;
      print_string [blue; Bold] ("----------------------------------------------------\n");
      print_string [cyan;Bold] ("\nMinimum bet: " ^ (string_of_int (Model.get_min_bet g)) ^ "\n");
      print_string [default_color; Bold] "\nPlayer information: \n";
      print_players p players;
  with
  | NoPlayersLeft -> print_string [] "\nStage ended!\n"
