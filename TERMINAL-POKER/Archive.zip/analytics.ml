open Model

let get_winner (g:Model.game) : (Model.player option) =
  (*[helper p_list acc] is the number of players in [p_list] with nonzero
  chips*)
  let rec helper (p_list:Model.player list) (acc:int) : int =
    match p_list with
    | [] -> acc
    | h::t -> if Model.get_chips h > 0 then helper t (acc + 1) else
      helper t acc
  in let x = helper (Model.get_players g) 0
  in if x > 1 then None
  else if x == 1 then
  let rec helper_2 (p_list:Model.player list) : Model.player option =
    match p_list with
    | [] -> failwith "Analytics - game_ended - 'living player not found'"
    | h::t -> if Model.get_chips h > 0 then Some h else helper_2 t
  in helper_2 (Model.get_players g)
  else failwith "Analytics - game_ended - 'zero players remaining alive'"

(**[game_ended g] is either [Some p] where p is the winning player of [g] or [None] if no player has won.
let game_ended (g:game) : player option =
  (*[players_with_chips p acc] is a list of players who still have chips*)
  let rec players_with_chips (p:player list) (acc:player list) : player list =
    match p with
    | [] -> acc
    | h::t -> if Model.get_chips h > 0 then players_with_chips t (h::acc)
      else players_with_chips t acc
  in
  if List.length (Model.get_players g) = 1 then Some (List.hd (Model.get_players g))
  else
    let player_chips = players_with_chips (Model.get_players g) [] in
    if List.length player_chips = 1 then Some (List.hd player_chips)
    else None**)
