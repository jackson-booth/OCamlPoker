open OUnit2
open Model
open Main
open Roundwinner
open Io

let make_deal_1_to_table_test
    (name:string)
    (g:game)
    (expected_table:card list) : test =
  name>:: fun _-> (
      let newgame = Model.deal_1_to_table g in 
      let table = Model.get_table newgame in 
      assert_equal expected_table table
    )

let make_deal_3_to_table_test
    (name:string)
    (g:game)
    (expected_table:card list) : test =
  name>:: fun _-> (
      let newgame = Model.deal_3_to_table g in 
      let table = Model.get_table newgame in 
      assert_equal expected_table table
    )

let make_deal_hands_test
    (name:string)
    (g:game)
    (expected_table:card list) : test =
  name >:: fun _-> (
      let dealtgame = Model.deal_hands g in 
      let plst = Model.get_players dealtgame in 
      let rec get_handslst (plst:player list) (acc:card list) : card list =
        match plst with 
        | [] -> acc
        | h::t -> let pcards = Model.get_player_cards h in 
          get_handslst t (acc@(pcards)) in 
      let cardlst = get_handslst plst [] in
      (assert_equal ((List.length plst) * 2) (List.length cardlst))
    )

let make_raise_pot_test
    (name:string)
    (g:game)
    (amt:int)
    (expected:(int*player)) : test =
  name >:: fun _-> (
      let updgame = Model.raise_pot g amt in 
      let tup = (Model.get_pot updgame, Model.get_current_player updgame) in 
      assert_equal expected tup
    )

let make_raise_pot_test
    (name:string)
    (g:game)
    (expected_pot:int) : test =
  name >:: fun _-> (
      let updgame = Model.match_pot g  in 
      let new_pot = (Model.get_pot updgame)in 
      assert_equal expected_pot new_pot
    )

let make_check_test
    (name:string)
    (g:game)
    (expected_player:Model.player) : test =
  name >:: fun _-> (
      let updgame = Model.check g  in 
      let next_player = (Model.get_current_player updgame)in 
      assert_equal expected_player next_player
    )

let make_fold_test  
    (name:string)
    (g:game)
    (expected_players: (Model.player) list) : test =
  name >:: fun _-> (
      let updgame = Model.check g  in 
      let updated_players = (Model.get_players updgame)in 
      assert_equal expected_players updated_players
    )

let make_end_round_test  
    (name:string)
    (g:game)
    (winner:Model.player)
    (expected_players: (Model.player) list) : test =
  name >:: fun _-> (
      let updgame = Model.check g  in 
      let updated_players = (Model.get_players updgame)in 
      assert_equal expected_players updated_players
    )

let make_raise_resolved_test  
    (name:string)
    (g:game)
    (expected_bool: bool) : test =
  name >:: fun _-> (
      let raised = Model.raise_resolved g  in 
      assert_equal expected_bool raised
    )

let make_reset_current_player_test  
    (name:string)
    (g:game)
    (expected_player: Model.player) : test =
  name >:: fun _-> (
      let new_game = Model.reset_current_player g  in 
      let player = Model.get_current_player new_game in
      assert_equal expected_player player
    )

(*ROUNDWINNER TESTING*)

let make_straight_flush_test
    (name:string)
    (clst:card list): test =
  name >:: fun _-> (
      let possible = Roundwinner.get_straight_flush clst in 
      let sorted = Roundwinner.reverse_sort_card_list possible in
      let sortedorig = Roundwinner.reverse_sort_card_list clst in
      assert_equal sorted sortedorig
    )

let make_fok_test
    (name:string)
    (clst:card list) : test =
  name >:: fun _-> (
      let possible = Roundwinner.is_n_of_kind 4 clst in 
      let sorted = Roundwinner.reverse_sort_card_list possible in
      let sortedorig = Roundwinner.reverse_sort_card_list clst in
      assert_equal sorted sortedorig
    )

let make_fh_test
    (name:string)
    (clst:card list) : test =
  name >:: fun _-> (
      let possible = Roundwinner.get_full_house clst in 
      let sorted = Roundwinner.reverse_sort_card_list possible in
      let sortedorig = Roundwinner.reverse_sort_card_list clst in
      assert_equal sorted sortedorig
    )

let make_flush_test
    (name:string)
    (clst:card list) : test =
  name >:: fun _-> (
      let possible = Roundwinner.get_flush clst in 
      let sorted = Roundwinner.reverse_sort_card_list possible in
      let sortedorig = Roundwinner.reverse_sort_card_list clst in
      assert_equal sorted sortedorig
    )

let make_tok_test
    (name:string)
    (clst:card list): test =
  name >:: fun _-> (
      let possible = Roundwinner.get_three_of_kind clst in 
      let sorted = Roundwinner.reverse_sort_card_list possible in
      let sortedorig = Roundwinner.reverse_sort_card_list clst in
      assert_equal sorted sortedorig
    )

let make_straight_test 
    (name:string)
    (clst:card list) : test =
  name >:: fun _-> (
      let possible = Roundwinner.get_three_of_kind clst in 
      let sorted = Roundwinner.reverse_sort_card_list possible in
      let sortedorig = Roundwinner.reverse_sort_card_list clst in
      assert_equal sorted sortedorig
    )

let make_tp_test 
    (name:string)
    (clst:card list): test =
  name >:: fun _-> (
      let possible = Roundwinner.get_two_pair clst in 
      let sorted = Roundwinner.reverse_sort_card_list possible in
      let sortedorig = Roundwinner.reverse_sort_card_list clst in
      assert_equal sorted sortedorig
    )

let make_pair_test 
    (name:string)
    (clst:card list) : test =
  name >:: fun _-> (
      let possible = Roundwinner.get_pair clst in 
      let sorted = Roundwinner.reverse_sort_card_list possible in
      let sortedorig = Roundwinner.reverse_sort_card_list clst in
      assert_equal sorted sortedorig
    )

(*STRAIGHT FLUSH TESTERS *)
let strflush0 =
  [{v=9; s=Hearts}; {v=8; s=Hearts}; {v=7; s=Hearts}; {v=6; s=Hearts}; 
   {v=5; s=Hearts}; {v=12; s=Spades}; {v=6; s=Clubs}]
(*Shouldn't work *)
let strflush1 =
  [{v=9; s=Hearts}; {v=8; s=Spades}; {v=7; s=Hearts}; {v=6; s=Hearts}; 
   {v=4; s=Hearts}; {v=2; s=Spades}; {v=2; s=Hearts}]
let strflush2 =
  [{v=15; s=Hearts}; {v=2; s=Hearts}; {v=3; s=Hearts}; {v=4; s=Hearts}; 
   {v=5; s=Hearts}; {v=12; s=Spades}; {v=6; s=Clubs}]
(*Shouldn't work*)
let strflush3 =
  [{v=9; s=Hearts}; {v=8; s=Clubs}; {v=7; s=Hearts}; {v=6; s=Hearts}; 
   {v=5; s=Hearts}; {v=12; s=Spades}; {v=6; s=Clubs}]
let strflush4 =
  [{v=2; s=Hearts}; {v=7; s=Hearts}; {v=11; s=Clubs}; {v=12; s=Clubs}; 
   {v=13; s=Clubs}; {v=14; s=Clubs}; {v=15; s=Clubs}]

(*FOUR OF A KIND TESTERS *)
let fok0 =
  [{v=9; s=Hearts}; {v=9; s=Clubs}; {v=9; s=Spades}; {v=9; s=Diamonds}; 
   {v=5; s=Hearts}; {v=12; s=Spades}; {v=6; s=Clubs}]
(*Shouldn't work *)
let fok1 =
  [{v=9; s=Hearts}; {v=8; s=Spades}; {v=7; s=Hearts}; {v=6; s=Hearts}; 
   {v=15; s=Hearts}; {v=15; s=Spades}; {v=15; s=Hearts}]
let fok2 =
  [{v=13; s=Spades}; {v=13; s=Clubs}; {v=3; s=Hearts}; {v=4; s=Hearts}; 
   {v=5; s=Hearts}; {v=13; s=Diamonds}; {v=13; s=Hearts}]
(*Shouldn't work*)
let fok3 =
  [{v=9; s=Hearts}; {v=9; s=Clubs}; {v=7; s=Hearts}; {v=6; s=Hearts}; 
   {v=5; s=Hearts}; {v=8; s=Spades}; {v=8; s=Clubs}]
let fok4 =
  [{v=7; s=Spades}; {v=7; s=Hearts}; {v=11; s=Clubs}; {v=7; s=Clubs}; 
   {v=13; s=Clubs}; {v=7; s=Diamonds}; {v=15; s=Clubs}]

(*FULLHOUSE TESTERS *)
let fh0 =
  [{v=9; s=Hearts}; {v=9; s=Clubs}; {v=9; s=Spades}; {v=9; s=Diamonds}; 
   {v=5; s=Hearts}; {v=2; s=Spades}; {v=2; s=Clubs}]
(*Shouldn't work *)
let fh1 =
  [{v=9; s=Hearts}; {v=8; s=Spades}; {v=7; s=Hearts}; {v=6; s=Hearts}; 
   {v=15; s=Hearts}; {v=15; s=Spades}; {v=15; s=Hearts}]
let fh2 =
  [{v=13; s=Spades}; {v=13; s=Clubs}; {v=3; s=Hearts}; {v=3; s=Spades}; 
   {v=5; s=Hearts}; {v=12; s=Diamonds}; {v=13; s=Hearts}]
(*Shouldn't work*)
let fh3 =
  [{v=8; s=Hearts}; {v=8; s=Clubs}; {v=7; s=Hearts}; {v=6; s=Hearts}; 
   {v=5; s=Hearts}; {v=9; s=Spades}; {v=9; s=Clubs}]
let fh4 =
  [{v=7; s=Spades}; {v=7; s=Hearts}; {v=11; s=Clubs}; {v=7; s=Clubs}; 
   {v=15; s=Clubs}; {v=15; s=Diamonds}; {v=15; s=Clubs}]

(*FLUSH TESTERS *)
let flush0 =
  [{v=9; s=Hearts}; {v=9; s=Hearts}; {v=9; s=Spades}; {v=9; s=Diamonds}; 
   {v=5; s=Hearts}; {v=12; s=Hearts}; {v=6; s=Clubs}]
(*Shouldn't work *)
let flush1 =
  [{v=9; s=Diamonds}; {v=8; s=Diamonds}; {v=7; s=Hearts}; {v=6; s=Hearts}; 
   {v=15; s=Hearts}; {v=15; s=Spades}; {v=15; s=Diamonds}]
let flush2 =
  [{v=13; s=Clubs}; {v=13; s=Clubs}; {v=3; s=Hearts}; {v=4; s=Hearts}; 
   {v=5; s=Hearts}; {v=13; s=Clubs}; {v=13; s=Clubs}]
(*Shouldn't work*)
let flush3 =
  [{v=9; s=Hearts}; {v=9; s=Clubs}; {v=9; s=Hearts}; {v=9; s=Hearts}; 
   {v=5; s=Spades}; {v=8; s=Spades}; {v=8; s=Clubs}]
let flush4 =
  [{v=7; s=Spades}; {v=7; s=Spades}; {v=11; s=Clubs}; {v=7; s=Clubs}; 
   {v=13; s=Clubs}; {v=7; s=Spades}; {v=15; s=Spades}]

(*STRAIGHT TESTERS *)
let straight0 =
  [{v=9; s=Hearts}; {v=8; s=Hearts}; {v=7; s=Hearts}; {v=6; s=Hearts}; 
   {v=5; s=Hearts}; {v=12; s=Spades}; {v=6; s=Clubs}]
(*Shouldn't work *)
let straight1 =
  [{v=9; s=Hearts}; {v=8; s=Spades}; {v=7; s=Hearts}; {v=6; s=Hearts}; 
   {v=4; s=Hearts}; {v=2; s=Spades}; {v=2; s=Hearts}]
let straight2 =
  [{v=15; s=Hearts}; {v=2; s=Diamonds}; {v=3; s=Hearts}; {v=4; s=Hearts}; 
   {v=5; s=Hearts}; {v=12; s=Spades}; {v=6; s=Clubs}]
(*Shouldn't work*)
let straight3 =
  [{v=9; s=Diamonds}; {v=7; s=Clubs}; {v=7; s=Hearts}; {v=6; s=Hearts}; 
   {v=5; s=Hearts}; {v=12; s=Spades}; {v=6; s=Clubs}]
let straight4 =
  [{v=2; s=Hearts}; {v=7; s=Hearts}; {v=11; s=Clubs}; {v=12; s=Clubs}; 
   {v=13; s=Spades}; {v=14; s=Clubs}; {v=15; s=Clubs}]

(*THREE OF A KIND TESTERS *)
let tok0 =
  [{v=9; s=Hearts}; {v=9; s=Spades}; {v=9; s=Diamonds}; {v=6; s=Hearts}; 
   {v=5; s=Hearts}; {v=12; s=Spades}; {v=6; s=Clubs}]
(*Shouldn't work *)
let tok1 =
  [{v=9; s=Hearts}; {v=8; s=Spades}; {v=7; s=Hearts}; {v=6; s=Hearts}; 
   {v=4; s=Hearts}; {v=9; s=Spades}; {v=8; s=Hearts}]
let tok2 =
  [{v=13; s=Hearts}; {v=13; s=Diamonds}; {v=3; s=Hearts}; {v=4; s=Hearts}; 
   {v=5; s=Hearts}; {v=13; s=Spades}; {v=13; s=Clubs}]
(*Shouldn't work*)
let tok3 =
  [{v=9; s=Diamonds}; {v=7; s=Clubs}; {v=7; s=Hearts}; {v=6; s=Hearts}; 
   {v=5; s=Hearts}; {v=9; s=Spades}; {v=6; s=Clubs}]
let tok4 =
  [{v=3; s=Hearts}; {v=7; s=Hearts}; {v=3; s=Clubs}; {v=12; s=Clubs}; 
   {v=13; s=Spades}; {v=14; s=Clubs}; {v=3; s=Clubs}]

(*TWO PAIR TESTERS *)
let tp0 =
  [{v=9; s=Hearts}; {v=9; s=Spades}; {v=6; s=Diamonds}; {v=6; s=Hearts}; 
   {v=5; s=Hearts}; {v=12; s=Spades}; {v=2; s=Clubs}]
(*Shouldn't work *)
let tp1 =
  [{v=9; s=Hearts}; {v=8; s=Spades}; {v=7; s=Hearts}; {v=6; s=Hearts}; 
   {v=2; s=Hearts}; {v=2; s=Spades}; {v=4; s=Hearts}]
let tp2 =
  [{v=13; s=Hearts}; {v=13; s=Diamonds}; {v=3; s=Hearts}; {v=4; s=Hearts}; 
   {v=5; s=Hearts}; {v=4; s=Spades}; {v=15; s=Clubs}]
(*Shouldn't work*)
let tp3 =
  [{v=9; s=Diamonds}; {v=7; s=Clubs}; {v=7; s=Hearts}; {v=6; s=Hearts}; 
   {v=5; s=Hearts}; {v=12; s=Spades}; {v=11; s=Clubs}]
let tp4 =
  [{v=3; s=Hearts}; {v=3; s=Hearts}; {v=8; s=Clubs}; {v=8; s=Clubs}; 
   {v=4; s=Spades}; {v=6; s=Clubs}; {v=12; s=Clubs}]

let identify_straight_flush = [
  make_straight_flush_test "(0) identify Straight Flush" strflush0;
  make_straight_flush_test "(2) identify Straight Flush" strflush2;
  make_straight_flush_test "(4) identify Straight Flush" strflush4;
]

let identify_fok = [
  make_fok_test "(0) identify fok" fok0;
  make_fok_test "(2) identify fok" fok2;
  make_fok_test "(4) identify fok" fok4;
]

let identify_fh = [
  make_fh_test "(0) identify full house" fh0;
  make_fh_test "(2) identify full house" fh2;
  make_fh_test "(4) identify full house" fh4;
]

let identify_flush = [
  make_flush_test "(0) identify flush" flush0;
  make_flush_test "(2) identify flush" flush2;
  make_flush_test "(4) identify flush" flush4;
]

let identify_straight = [
  make_straight_test "(0) identify straight" straight0;
  make_straight_test "(2) identify straight" straight2;
  make_straight_test "(4) identify straight" straight4;
]

let identify_tok = [
  make_tok_test "(0) identify tok" tok0;
  make_tok_test "(2) identify tok" tok2;
  make_tok_test "(4) identify tok" tok4;
]

let identify_tp = [
  make_tp_test "(0) identify tp" tp0;
  make_tp_test "(2) identify tp" tp2;
  make_tp_test "(4) identify tp" tp4;
]

let suite =
  "test suite for Poker"  >::: List.flatten [
    identify_straight_flush;
    identify_fok;
    identify_fh;
    identify_flush;
    identify_tok;
    identify_tp;
  ]

let _ = run_test_tt_main suite