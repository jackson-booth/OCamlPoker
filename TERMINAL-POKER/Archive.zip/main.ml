open Model
open View
open ANSITerminal
open Io
open Ai
open Roundwinner

exception GameDone

(**[next_player_goes] handles printing between player turns**)
let next_player_goes () =
    erase Above;
    print_string [yellow] "Your turn is now over. Press any key if you are the next player.";
    read_line ();
    erase Above

(*[get_command g p] is the response of player [p] to gamestate [g]. This
  function gets current player input and maps that to a response, either
  through querying the user or the AI for the response.
*)
let rec get_command (g:Model.game) (p:Model.player) : Io.response =
  View.print_game g;
  save_cursor ();
  print_string [green] "Type 'help' for help\n> ";
  if true || Model.is_person p then
    match read_line () with
    | exception End_of_file -> failwith "Error 0"
    | (str:string) -> try let x:Io.response = Io.parse str in match x with
      | Io.Raise i -> Io.Raise i
      | Io.Match -> Io.Match
      | Io.Check -> Io.Check
      | Io.Fold -> Io.Fold
      | Io.Help -> Io.Help
      | Io.Exit -> Io.Exit
      with
      | Io.Malformed -> print_string [red] "\nThat wasn't a valid command :(. Here's some help tips!\n"; View.print_play_help (); read_line (); erase Above; get_command g p;
  else let x:string * Io.response = Ai.get_move g p in
    print_string [] (fst x);
    let cursor_pos = pos_cursor () in
    restore_cursor ();
    erase Above;
    set_cursor (fst cursor_pos) (snd cursor_pos);
    snd x

(**[play_raise g] is [g] after all players in [g] have either matched the
    minimum bet or folded.
    Requires: [g] is a valid game**)
let rec play_raise (g:Model.game) : Model.game =
  let raise_played = Model.raise_resolved g in
  if raise_played then g
  else try let p = Model.get_current_player g in
    let command = get_command g p in
    match command with
    | Io.Raise i -> let g = Model.raise_pot g i in next_player_goes ();
      print_string [yellow] ((Model.get_name p) ^
                              " raised by " ^ (string_of_int i));
      play_raise g
    | Io.Match -> let g = Model.match_pot g in next_player_goes ();
      print_string [green] ((Model.get_name p) ^
                              " matched!");
      play_raise g
    | Io.Fold -> let g = Model.match_pot g in next_player_goes ();
      print_string [red] ((Model.get_name p) ^
                              " folded!");
      play_raise g
    | Io.Help -> View.print_help (); g |> play_raise
    | Io.Exit -> View.print_exit (); raise GameDone
    | _ -> erase Above; Pervasives.print_string "\nRight now you may only raise, match, or fold; try again"; play_raise g
  with
  | NoPlayersLeft -> play_raise (Model.reset_current_player g)
  | NotEnoughChips -> erase Above; print_string [red] "\nAck! You don't have enough chips to
  keep playing, so you folded instead!"; g |> Model.fold |> play_raise

(*[play_stage g] steps game [g] through a stage.
  Requires: [g] is a valid game.*)
let rec play_stage (g:Model.game) : Model.game =
  try let p = Model.get_current_player g
    in let command = get_command g p in
    match command with
    | Io.Raise i -> let g = Model.raise_pot g i in next_player_goes ();
      print_string [yellow] ((Model.get_name p) ^
                              " raised by " ^ (string_of_int i));
      play_stage g
    | Io.Match -> let g = Model.match_pot g in next_player_goes ();
      print_string [green] ((Model.get_name p) ^
                              " matched!");
      play_stage g
    | Io.Check -> let g = Model.check g in next_player_goes ();
      print_string [green] ((Model.get_name p) ^
                              " checked!");
      play_stage g
    | Io.Fold -> let g = Model.match_pot g in next_player_goes ();
      print_string [red] ((Model.get_name p) ^
                              " folded!");
      play_stage g
    | Io.Help -> View.print_help (); read_line (); g
    | Exit -> View.print_exit (); raise GameDone
  with
  | NoPlayersLeft -> Model.reset_current_player g
  | MustMatchPot -> erase Above; print_string [red] "\nAck! You don't have enough chips to match the minimum bet; so you folded instead!"; g |> Model.fold |> play_stage
  | CantRaise -> erase Above; print_string [red] "\nAck! You don't have enough chips raise or bet by that much; Try again!"; play_stage g

(**[play_round g] is [g] after a round has been played.
Requires: [g] is a valid game**)
let play_round (g:Model.game) : Model.game =
  let g = Model.deal_hands g in
  let g = erase Above; print_string [default_color; Bold] "\n\nThe Pre-flop\n"; play_stage g in
  let g = Model.deal_3_to_table g in
  let g = erase Above; print_string [default_color; Bold] "\n\nThe Flop\n"; play_stage g in
  let g = Model.deal_1_to_table g in
  let g = erase Above; print_string [default_color; Bold] "\n\nThe Turn\n"; play_stage g in
  let g = Model.deal_1_to_table g in
  let g = erase Above; print_string [default_color; Bold] "\n\nThe River\n"; play_stage g in
  let winner = Roundwinner.get_round_winner g in
  Model.end_round g winner

let rec play_game (g:Model.game) : Model.player =
  let r = play_round g
  in let p:Model.player option = Analytics.get_winner r
  in match p with
  | Some p -> p
  | None -> play_game r

let rec play (g:Model.game) : unit =
  let p = play_game g in
  View.print_winner p g

and main () : unit =
  ANSITerminal.(print_string [default_color]
    "\n\nWelcome to The Barely Implemented Casino.\n");
    print_string [default_color] "Please enter the number of players for your game, and the
  number of chips each player should start with, separated by a space.\nFor instance, '4 1701' is a four player game where each player starts with 1701
  chips.\n";
  let rec helper () : unit =
    print_string  [cyan] "> ";
    try let x = read_line ()
      in match x with
      | exception End_of_file -> print_string [] "foo"; ()
      | str -> try let params = Io.parse_params str in
              let g = Model.instantiate params in
              try play g with GameDone -> ()
              with Sys_error _ -> helper ()
            with Io.Malformed ->
            print_string [red] "Your input was invalid--try again?\n";
            helper ()
  in helper ()

let () = main ()
