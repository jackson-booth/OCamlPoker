let hours_worked = [10; 8; 8; 10]

(* These are for cbb67, jrb485, rt363, tme28, respectively. *)
