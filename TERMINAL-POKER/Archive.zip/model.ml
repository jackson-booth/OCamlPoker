exception NoPlayersLeft
exception NotEnoughChips
exception CantRaise
exception MustMatchPot

type suit = Hearts | Clubs | Diamonds | Spades

type card = {
  v:int;
  s:suit;
}

type player = {
  name:string;
  cards:card list;
  chips:int;
  amt_bet:int;
  folded:bool;
  is_person:bool;
  next:int;
}

type deck = card list

type game = {
  pot:int;
  players:player list;
  table:card list;
  deck:deck;
  min_bet:int;
  current_player:int;
}

let build_deck () = [
  {v=14;s=Hearts};{v=14;s=Clubs};{v=14;s=Diamonds};{v=14;s=Spades};
  {v=13;s=Hearts};{v=13;s=Clubs};{v=13;s=Diamonds};{v=13;s=Spades};
  {v=12;s=Hearts};{v=12;s=Clubs};{v=12;s=Diamonds};{v=12;s=Spades};
  {v=11;s=Hearts};{v=11;s=Clubs};{v=11;s=Diamonds};{v=11;s=Spades};
  {v=10;s=Hearts};{v=10;s=Clubs};{v=10;s=Diamonds};{v=10;s=Spades};
  {v=9;s=Hearts};{v=9;s=Clubs};{v=9;s=Diamonds};{v=9;s=Spades};
  {v=8;s=Hearts};{v=8;s=Clubs};{v=8;s=Diamonds};{v=8;s=Spades};
  {v=7;s=Hearts};{v=7;s=Clubs};{v=7;s=Diamonds};{v=7;s=Spades};
  {v=6;s=Hearts};{v=6;s=Clubs};{v=6;s=Diamonds};{v=6;s=Spades};
  {v=5;s=Hearts};{v=5;s=Clubs};{v=5;s=Diamonds};{v=5;s=Spades};
  {v=4;s=Hearts};{v=4;s=Clubs};{v=4;s=Diamonds};{v=4;s=Spades};
  {v=3;s=Hearts};{v=3;s=Clubs};{v=3;s=Diamonds};{v=3;s=Spades};
  {v=2;s=Hearts};{v=2;s=Clubs};{v=2;s=Diamonds};{v=2;s=Spades};
]

let has_folded (p:player) : bool = p.folded

let get_name (p:player) : string = p.name

let get_player_cards (p:player) : card list = p.cards

let is_person (p:player) : bool = p.is_person

let get_chips (p:player) : int = p.chips

let get_player_bet (p:player) : int = p.amt_bet

let get_players (g:game) : player list = g.players

let get_pot (g:game) : int = g.pot

let get_deck (g:game) : deck = g.deck

let get_table (g:game) : card list = g.table

let get_min_bet (g:game) : int = g.min_bet

let get_current_player (g:game) : player =
  try List.nth (g.players) (g.current_player)
  with _ -> raise NoPlayersLeft

(*[next_player g] is [p] where [p] is the next player to go (and not folded)
  in [g]
  Raises: [NoPlayersLeft] if no players can move*)
let next_player (g:game) : player =
  if g.current_player = -1 then raise NoPlayersLeft
  else try let rec find_next_unfolded (p:player) : player =
             if p.folded then find_next_unfolded (List.nth (g.players) (p.next))
             else p
      in find_next_unfolded (List.nth (g.players) (g.current_player + 1))
    with _ -> raise NoPlayersLeft

(*[next_player g] is the index of the next player to go in [g]*)
let next_player_index (g:game) : int =
  try let p = next_player g in
    let rec find_player (n:int) (p_list:player list) : int =
      match p_list with
      | [] -> -1
      | h::t -> if h = p then n else find_player (n+1) t
    in
    find_player 0 g.players
  with NoPlayersLeft -> -1

let raise_pot (g:game) (amt:int) : game =
  try let p = get_current_player g in
    let amt_1 = if p.amt_bet = g.min_bet then amt
      else (g.min_bet - p.amt_bet + amt) in
    let new_players = List.map (
        fun x -> if x = p then
            if p.chips >= amt_1 then {p with
                                      chips = p.chips (*- g.min_bet*) - amt_1;
                                      amt_bet = p.amt_bet + amt_1 (*+ g.min_bet*)
                                     }
            else raise CantRaise
          else x) g.players
    in {g with
        pot = g.pot (*+ g.min_bet*) + amt_1;
        min_bet = g.min_bet + amt;
        players = new_players;
        current_player = next_player_index g;
       }
  with
  | NoPlayersLeft -> raise NoPlayersLeft
  | CantRaise -> raise CantRaise

let match_pot (g:game) : game =
  try let p = get_current_player g in
    let amt = g.min_bet - p.amt_bet in
    let new_players = List.map (
        fun x -> if x = p then
            if p.chips >= amt then {p with
                                    chips = p.chips (*- g.min_bet*) - amt;
                                    amt_bet = p.amt_bet + amt (*+ g.min_bet*)
                                   }
            else raise NotEnoughChips
          else x) g.players
    in {g with
        pot = g.pot (*+ g.min_bet*) + amt;
        min_bet = g.min_bet;
        players = new_players;
        current_player = next_player_index g;
       }
  with
  | NoPlayersLeft -> raise NoPlayersLeft
  | NotEnoughChips -> raise NotEnoughChips

let check (g:game) : game =
  try let p = get_current_player g in
    if p.amt_bet >= g.min_bet then
      {g with current_player = next_player_index g }
    else raise MustMatchPot
  with
  | NoPlayersLeft -> raise NoPlayersLeft
  | MustMatchPot -> raise MustMatchPot

let fold (g:game) : game =
  try let p = get_current_player g in
    let new_players = List.map (
        fun x -> if x = p then {x with folded=true} else x
      ) g.players
    in {g with
        players = new_players;
        current_player = next_player_index g;
       }
  with NoPlayersLeft -> raise NoPlayersLeft

(**[pop_card d] is a tuple [c,d'] where [c] is the first card of [d] and [d']
   is [d] without its first card**)
let pop_card (d:deck) : card * deck =
  match d with
  | [] -> failwith "Empty deck"
  | h::t -> (h,t)

let deal_1_to_table (g:game) : game =
  let tup = pop_card g.deck in
  {g with table = (fst tup)::g.table; deck = snd tup;}

let deal_3_to_table (g:game) : game =
  g |> deal_1_to_table |> deal_1_to_table |> deal_1_to_table

(*[deal_2_to_players p_list acc d] is [d','p_list], where [d'] is the deck
  missing the cards dealt to players in [p_list] to form, [p_list'], in which
  each player in [p_list] has been dealt two cards from [d]*)
let rec deal_2_to_players (p_list:player list) (acc:player list) (d:deck) :
  (player list) * deck =
  match p_list with
  | [] -> (acc,d)
  | h::t -> let tup1 = pop_card d in
    let tup2 = pop_card (snd tup1) in
    let acc = ({h with cards = (fst tup1)::[(fst tup2)]}::acc) in
    deal_2_to_players t acc (snd tup2)

(**[deal_hands g] is the game [g] after each player has been dealt two cards
   and the deck has been updated*)
let deal_hands (g:game) : game =
  let updated = deal_2_to_players g.players [] g.deck in
  {g with
   players = fst updated;
   deck = snd updated;
  }

(**[shuffle c] is [c] after shuffling**)
let shuffle (c:card list) : card list =
  let seed = Random.self_init() in
  let rand_times = (Random.int 450) + 450 in
  let rec shuffle_helper (c:card list) (n:int) : card list =
    let random_sort (c1:card) (c2:card) = (Random.int 3) - 1 in
    let shuffled = List.sort random_sort c in
    if n = 1 then shuffled
    else shuffle_helper shuffled (n-1) in
  shuffle_helper c rand_times

(**[get_new_deck] is a shuffled new 52-card deck**)
let get_new_deck () =
  shuffle (build_deck ())

let end_round (g:game) (winner:player) : game =
  let new_players = List.map (
      fun p -> if p = winner then
          {p with
           chips = p.chips + g.pot;
           amt_bet = 0;
           folded = false;
          }
        else {p with
              amt_bet = 0;
              folded = false;
             }
    ) g.players
  in
  let new_players,deck = new_players,(get_new_deck ())
  in {
    pot = 0;
    players = new_players;
    table = [];
    deck = deck;
    min_bet = 0;
    current_player = 0;
  }

let raise_resolved (g:game) : bool =
  let min_bet = g.min_bet in
  let rec helper (p_list:player list) (acc:bool) : bool =
    match p_list with
    | [] -> acc
    | h::t -> helper t acc && ((h.amt_bet = min_bet) || h.folded)
  in helper g.players true

let reset_current_player (g:game) : game =
  {g with current_player = 0}

let instantiate (input:(string * bool) list * int) : game =
  let rec build_players (n:int) (acc:player list) : player list =
    if n = -1 then match acc with
      | [] -> acc
      | h::t -> List.rev ({h with next = -1}::t)
    else let p = {
        name = (fst (List.nth (fst input) n));
        cards = [];
        amt_bet = 0;
        chips = (snd input);
        folded = false;
        is_person = (snd (List.nth (fst input) n));
        next = (n+1);
      } in build_players (n-1) (p::acc)
  in
  let players = build_players (List.length (fst input) - 1) [] in
  let players,deck =  players, (get_new_deck()) in
  {
    pot = 0;
    players = players;
    table = [];
    deck = deck;
    min_bet = 0;
    current_player = 0;
  }
