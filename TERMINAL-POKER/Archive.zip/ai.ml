open Model
open Io

let get_move (g:Model.game) (p:Model.player) : string * Io.response =
  "Folded", Io.Fold
