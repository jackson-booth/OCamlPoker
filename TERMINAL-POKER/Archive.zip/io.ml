exception Empty
exception Malformed
exception InvalidInstantiation

type response = Raise of int | Match | Check | Fold | Help | Exit

(**[remove_empty_spaces s n] is [s] with " " and  "" elements removed,
  but otherwise unchanged.
  Requires: [n] is an empty list when this function is first *)
let rec remove_empty_spaces (str_list: string list)
  (new_str_list:string list) : string list =
  match str_list with
  | [] -> List.rev new_str_list
  | " "::t -> remove_empty_spaces t new_str_list
  | ""::t -> remove_empty_spaces t new_str_list
  | h::t -> remove_empty_spaces t (h::new_str_list)

(**[parse s] is a command created from [s] if [s] is a valid command. A valid
    command is either "quit" or "go ?", where "?" is a part of the input string.
    Raises: [Empty] if [s] is "", or [malformed] if [s] is not a recognized
    command.
    Example: parse "go Prydain" is a Go of ["Prydain"]*)
let parse (str:string) : response =
  let str_as_list = String.split_on_char  ' ' str in
  let new_str_as_list = remove_empty_spaces str_as_list [] in
  match new_str_as_list with
  | ["fold"] -> Fold
  | ["bet";i] -> Raise (int_of_string i)
  | ["raise";i] -> Raise (int_of_string i)
  | ["match"] -> Match
  | ["check"] -> Check
  | ["help"] -> Help
  | ["exit"] -> Exit
  | _ -> raise Malformed

let parse_params (str:string) : (string * bool) list * int =
  let str_as_list = String.split_on_char  ' ' str in
  let new_str_as_list = remove_empty_spaces str_as_list [] in
  match new_str_as_list with
  | [num_players;chips] ->
    let rec get_players (num_players:int) (acc:(string * bool) list) :
    (string * bool) list =
    match num_players with
    | 0 -> acc
    | n -> get_players (n-1) ((("Player_" ^ (string_of_int n)),true)::acc)
  in let players = get_players (int_of_string num_players) []
  in (List.rev players),(int_of_string chips)
  | _ -> raise Malformed
