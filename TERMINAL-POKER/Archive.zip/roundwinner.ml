open Model

type pokerhand = 
  | StraightFlush of (int * card list)
  | FourOfKind of (int * card list)
  | FullHouse of (int * card list)
  | Flush of (int * card list)
  | Straight of (int * card list)
  | ThreeOfKind of (int * card list)
  | TwoPair of (int * card list)
  | Pair of (int * card list)
  | HighCard of (int * card list)

let get_int_list (c: card list) : int list = List.map (fun a -> a.v) c

(**[unwrap x] is the value stored in an optional. Fails if there is nothing
   to unwrap i.e. the optional is variant type None. *)
let unwrap (x:'a option) : 'a = 
  match x with
  | None -> failwith "cannot unwrap"
  | Some s -> s

(**[take_first_n_cards c n] takes the first [n] cards from a card list
   [c]. This is a useful utility function for extracting hands and subhands. 
   Precondition: [n] cannot be more than the length of card list [c].*)
let rec take_first_n_cards (n:int) (c: card list) : card list =
  if n = 0 then []
  else if List.length c < n then c
  else (List.hd c) :: take_first_n_cards (n-1) (List.tl c)

(**[reverse_sort_card_list c] sorts card list [c] in weak decreasing order by
   card value. The suit of the card does not affect its order*)
let reverse_sort_card_list (c: card list) : card list = 
  let reverse_sort_card (c1: card) (c2: card) : int = c2.v - c1.v 
  in List.sort reverse_sort_card c

(**[high_card c] returns the highest card in a card list [c] by 
   reverse sorting and taking the first element*)
let high_card (c: card list) : int = 
  (c |> reverse_sort_card_list |> List.hd).v

let low_card (c: card list) : int = 
  (c |> reverse_sort_card_list |> List.rev |> List.hd).v

(**[is_straight c] is true if the card list [c] contains 5 cards in strictly
   decreasing order and returns list the contains straight and the hand that
   contains the highest straight. *)
let rec get_straight (cl: card list) : card list = 
  (* If there is an ace (represented by 15) include an ace with value 14.
     This is because ace can be used as a high card and low card. *)
  let plus_low_ace (cli: card list) = 
    if (cli |> high_card) = 15 then {v=1; s=Hearts} :: cli else cli in 
  let c = cl |> plus_low_ace |> reverse_sort_card_list  in 
  let is_straight_helper (c: card list): card list = 
    if (List.length c >= 5 && 
        (List.nth c 0).v - (List.nth c 1).v = 1 &&
        (List.nth c 1).v - (List.nth c 2).v = 1 &&
        (List.nth c 2).v - (List.nth c 3).v = 1 &&
        (List.nth c 3).v - (List.nth c 4).v = 1) 
    then take_first_n_cards 5 c
    else [] in
  let hand = is_straight_helper c in
  if hand = [] && List.length c >= 5 then get_straight (List.tl c)
  else hand

(**[get_flush c] is true if the card list [c] contains 5 cards of the
   same suit and returns the highest hand that is a flush. *)
let get_flush (c: card list) : card list =
  (* [has_flush_helper] returns a true if there is a flush and 
     the suit of the flush if it exists. It takes an accumulating tuple
     that counts how many cards of each suit there are. *)
  let rec has_flush_helper (c: card list) (acc: int*int*int*int) : suit option =
    match c with
    | [] -> (match acc with (a,b,c,d) -> 
        if a >= 5 then Some Hearts
        else if b >= 5 then Some Clubs
        else if c >= 5 then Some Diamonds
        else if d >= 5 then Some Spades
        else None)
    | h::t -> 
      (*[update_acc c old] is a tuple where the nth entry is updated
        depending on the suit. *)
      let update_acc (c: card) (old_acc: int*int*int*int) = 
        match c.s with
        | Hearts -> (match old_acc with (a, b, c, d) -> (a+1, b, c, d))
        | Clubs -> (match old_acc with (a, b, c, d) -> (a, b+1, c, d))
        | Diamonds -> (match old_acc with (a, b, c, d) -> (a, b, c+1, d))
        | Spades -> (match old_acc with (a, b, c, d) -> (a, b, c, d+1))
      in has_flush_helper t (update_acc h acc) in
  let possible_suit = has_flush_helper c (0,0,0,0) in
  (* Gets the cards of a certain suit in a card list. *)
  let get_flush_hand (s: suit) (c: card list): card list = 
    List.filter (fun a -> a.s = s) c in
  match possible_suit with 
  | None -> []
  | Some x -> c |> get_flush_hand x |> reverse_sort_card_list |> take_first_n_cards 5

(**[is_straight_flush c] is true if the card list [c] is a straight and
   a flush and returns the hand that satisfies these properties. Otherwise, none.*)
let rec get_straight_flush (c: card list) : card list = 
  (*This goes through all the possible subsets of the card list, but only
    subsets of size 5 or greater are valid. *)
  if List.length c >= 5 then
    let ordered = c |> reverse_sort_card_list in
    let straight = ordered |> get_straight in
    (* Checks if the card list contains a straight. *)
    if straight <> [] then 
      let flush = get_flush straight in 
      if flush <> [] then flush
      (* If not checks if there if there is another straight that is 
         smaller but might be a flush. *)
      else get_straight_flush (List.tl ordered)
      (*If not checks if there if there is another straight that is 
        smaller but might be a flush. *)
    else get_straight_flush (List.tl ordered)
  else []

(**[card_frequency clst] is an [int array] size 15, where [int array][i-1] is
   an integer corresponding to the number of cards in [clst] that have value i
   NOTE: An ace (default value 15) also has value 1
   Example:
   [card_frequency [{v=3, s=Hearts}; {v=4; s=Spades}; {v=4; s=Clubs}; 
                      {v=15; s=Diamonds}]]
                      returns [|1; 0; 1; 2; 0; 0; 0; 0; 0; 0; 0; 0; 0; 0; 1|] *)
let card_frequency (c: card list) : int array =
  let freq_array = Array.make 16 0 in
  let rec card_freq_helper (c: card list) : unit =
    match c with
    | [] -> ()
    | h::t -> freq_array.(h.v) <- freq_array.(h.v) + 1;  
      card_freq_helper t in
  card_freq_helper c; freq_array

(**[is_n_of_kind n clst] returns the card list that contains this n_of_kind 
   grouping otherwise returns [] *)
let is_n_of_kind (n:int) (clst:card list) : card list =
  let freq_distr = card_frequency clst in 
  let desc_freq_lst = freq_distr |> Array.to_list 
                      |> List.rev in
  let rec n_matcher (n:int) (v:int) (freqlst:int list) : int = (*returns the value that corresponds to the best nok hand*)
    match freqlst with
    | [] -> -1
    | h::t -> if h >= n then v else n_matcher n (v-1) t
  in 
  (* Should be 14 because *)
  let nok_val = n_matcher n 15 desc_freq_lst in 
  if nok_val = -1 then []
  else let rawlst = List.filter (fun c -> c.v = nok_val) clst in (*This filters through clst and builds
                                                                   a cardlist where all cards have value = nok_val*)
    take_first_n_cards n rawlst

let find_freq (target: int) (freq: int array) : int list =
  let rec get_kickers_helper (f: int array) (n: int) (acc: int list) =
    if (Array.length f) > n then 
      if f.(n) = target then get_kickers_helper f (n+1) (n::acc)
      else  get_kickers_helper f (n+1) acc
    else acc
  in (get_kickers_helper freq 0 []) |> List.rev


(*let is_four_of_kind (c:int array): bool * (int option) * (int option) =
  let fours = find_freq 4 c in
  if length fours = 1 then
    let type = hd fours in
  let kicker = c |> find_freq 1 |> hd in
  (true, Some type, Some kicker)
  else (false, None, None) *)

let get_full_house (clist: card list): card list =
  let repeats3 = is_n_of_kind 3 clist in
  if is_n_of_kind 3 clist = [] then []
  else (
    let sublst = List.filter (fun c -> not (List.mem c repeats3)) clist in 
    let repeats2 = is_n_of_kind 2 sublst in 
    if repeats2 = [] then []
    else repeats3@repeats2
  )

(*[get_three_of_kind c] gets the three of a kind from a card list if
  there is one and returns the empty list otherwise. *)
let get_three_of_kind (c: card list): card list =
  let repeats3 = c |> is_n_of_kind 3 in
  if repeats3 = [] then []
  else 
    let card_val = (List.hd repeats3).v in
    let kickers = c |> reverse_sort_card_list 
                  |> List.filter (fun c -> c.v <> card_val) |> take_first_n_cards 2
    in repeats3@kickers


let get_two_pair (c: card list): card list = 
  let fstrepeats2 = c |> is_n_of_kind 2 in
  if fstrepeats2 = [] then []
  else 
    let fstcard_val = (List.hd fstrepeats2).v in
    let sublist = c |> reverse_sort_card_list |> List.filter (fun c -> c.v <> fstcard_val) in
    let sndrepeats2 = sublist |> is_n_of_kind 2 in
    if sndrepeats2 = [] then []
    else
      let sndcard_val = (List.hd sndrepeats2).v in
      let kickers = c |> reverse_sort_card_list 
                    |> List.filter (fun c -> c.v <> sndcard_val) |> take_first_n_cards 1
      in fstrepeats2@sndrepeats2@kickers

let get_pair (c: card list): card list  =
  let repeats2 = c |> is_n_of_kind 2 in
  if repeats2 = [] then []
  else 
    let card_val = (List.hd repeats2).v in
    let kickers = c |> reverse_sort_card_list 
                  |> List.filter (fun c -> c.v <> card_val) |> take_first_n_cards 3
    in repeats2@kickers

let get_high_card (c: card list): card list = 
  c |> reverse_sort_card_list |> take_first_n_cards 5

let identify_hand (c: card list) : pokerhand =
  let sf = get_straight_flush c in
  let fh = get_full_house c in
  let f = get_flush c in
  let s = get_straight c in
  let tok = get_three_of_kind c in
  let tp = get_two_pair c in
  let p = get_pair c in
  let hc = get_high_card c in
  if sf <> [] then StraightFlush (9, sf)
  else if fh <> [] then FullHouse (7, fh)
  else if f <> [] then Flush (6, f)
  else if s <> [] then Straight (5, s)
  else if tok <> [] then ThreeOfKind (4, tok)
  else if tp <> [] then TwoPair (3, tp)
  else if p <> [] then Pair (2, p)
  else if hc <> [] then HighCard (2, hc)
  else failwith "Precondition violated: cardlist empty"

let get_int_val (ph: pokerhand) : int =
  match ph with
  | StraightFlush a -> fst a
  | FourOfKind a -> fst a
  | FullHouse a -> fst a
  | Flush a -> fst a
  | Straight a -> fst a
  | ThreeOfKind a -> fst a
  | TwoPair a -> fst a
  | Pair a -> fst a
  | HighCard a -> fst a

let compare_hands (cl1: card list) (cl2: card list) : int = 
  let hand1 = identify_hand cl1 in 
  let hand2 = identify_hand cl2 in 
  (get_int_val hand2) - (get_int_val hand1)

let get_player_cards_tuple_list (g: game) : (player * card list) list =
  let pl = get_players g in
  let table = get_table g in
  List.map (fun a -> (a, (get_player_cards a)@table) ) pl

let get_round_winner (g: game) : player =
  let player_cl_tup = get_player_cards_tuple_list g in
  let sorted = List.sort (fun a b -> (compare_hands (snd a) (snd b))) player_cl_tup
  in fst(List.hd sorted)

